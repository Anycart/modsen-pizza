INSERT INTO category (description, name) VALUES
('hello', 'man');