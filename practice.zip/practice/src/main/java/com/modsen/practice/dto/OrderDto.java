package com.modsen.practice.dto;

public class OrderDto {
}
